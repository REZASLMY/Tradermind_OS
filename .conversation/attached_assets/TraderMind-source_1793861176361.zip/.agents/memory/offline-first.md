---
name: Offline-first expectations
description: The user's expectation that core TraderMind work remains available offline, including transparency for speech features.
---

کاربر TraderMind را نرم‌افزاری آفلاین می‌داند. تایپ صوتی مرورگر استثناست و نباید آفلاین تضمین‌شده معرفی شود؛ تشخیص گفتار فارسی محلی هنوز داخل برنامه وجود ندارد.

**Why:** کاربر با اشاره به آفلاین بودن برنامه دربارهٔ کارکرد تایپ صوتی پرسید.

**How to apply:** قابلیت‌های اصلی ثبت و مرور معاملات را محلی و آفلاین نگه دار؛ برای هر قابلیت وابسته به سرویس آنلاین، محدودیت را در رابط کاربری روشن بگو.

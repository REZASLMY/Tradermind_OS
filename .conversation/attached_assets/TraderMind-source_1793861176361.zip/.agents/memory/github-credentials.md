---
name: GitHub credentials
description: Safe authentication rule for repository operations.
---

GitHub operations must use the Replit-managed GitHub connection. Personal access tokens must not be requested in chat, written to files, or exposed in logs.

**Why:** The integration provides OAuth-based access without exposing a reusable credential to the project or conversation.

**How to apply:** If a push is rejected, report the repository/branch status and ask the user to authorize the GitHub connection or resolve branch protection in GitHub; do not work around it with a token or force push.

Git access and the GitHub REST connection are separate: a Replit-managed Git remote may allow authorized pushes even when the API connector is unavailable to CodeExecution.

**Why:** In this workspace, the Git remote accepted a push while the GitHub API integration was still unavailable.

**How to apply:** Verify the target remote and try Git through Replit's managed authentication before asking the user to reconnect. Never request a personal token. If Actions API access is unavailable, use a narrowly scoped branch-triggered build when appropriate instead of a release tag.
/**
 * تست‌های analyticsService.ts — Prompt 4 (Part 10)
 * تست محاسبات خالص (pure functions) با computeAnalytics
 */
import { describe, it, expect } from 'vitest';
import { computeAnalytics } from '../analyticsService';
import type { Trade } from '../../db/database';

// ─── داده‌های تستی ────────────────────────────────────────────────────────────

// P/L پیش‌فرض باید با result سازگار باشد (طبقه‌بندی برد/باخت از علامت سود خالص می‌آید)
const DEFAULT_PNL_BY_RESULT: Partial<Record<Trade['result'], number>> = {
  win: 100, 'partial-win': 50, loss: -50, 'partial-loss': -25, breakeven: 0,
};

function makeTrade(overrides: Partial<Trade> = {}): Trade {
  const derivedPnl = overrides.profitLoss === undefined && overrides.result !== undefined
    ? DEFAULT_PNL_BY_RESULT[overrides.result]
    : undefined;
  const trade: Trade = {
    id: `t_${Math.random().toString(36).slice(2)}`,
    sessionId: null,
    strategyId: null,
    accountId: null,
    boxId: null,
    symbol: 'EURUSD',
    market: null,
    direction: 'long',
    entryPrice: 1.08,
    exitPrice: 1.09,
    stopLoss: 1.075,
    takeProfit: null,
    positionSize: 1,
    riskPercentage: 1,
    riskAmount: 50,
    rMultiple: 2,
    result: 'win',
    profitLoss: 100,
    fees: null,
    status: 'closed',
    openedAt: Date.now() - 3600000,
    closedAt: Date.now(),
    reasonForExit: null,
    emotions: '[]',
    emotionNotes: null,
    notes: null,
    screenshots: '[]',
    adherenceScore: null,
    adherenceRating: null,
    adherenceNotes: null,
    review: '{}',
    postTradeReview: '{}',
    tags: '[]',
    createdAt: Date.now(),
    liveMonitoring: null,
    plannedEntry: null,
    plannedSL: null,
    plannedTP: null,
    plannedRR: null,
    plannedRisk: null,
    plannedPositionSize: null,
    tradingSession: null,
    setupType: null,
    timezone: null,
    entryReason: null,
    lesson: null,
    slMoved: null,
    tpMoved: null,
    partialClose: null,
    addedToPosition: null,
    reducedPosition: null,
    manualExit: null,
    managementReason: null,
    mtfAnalysis: null,
    ...overrides,
  };
  if (derivedPnl !== undefined) trade.profitLoss = derivedPnl;
  return trade;
}

// ─── تست‌های computeAnalytics ────────────────────────────────────────────────

describe('computeAnalytics — TradeSummary', () => {
  it('باید summary درست برای ۵ برد و ۲ باخت محاسبه کند', () => {
    const trades = [
      makeTrade({ result: 'win', rMultiple: 2, profitLoss: 100 }),
      makeTrade({ result: 'win', rMultiple: 1.5, profitLoss: 75 }),
      makeTrade({ result: 'win', rMultiple: 3, profitLoss: 150 }),
      makeTrade({ result: 'win', rMultiple: 1, profitLoss: 50 }),
      makeTrade({ result: 'win', rMultiple: 2, profitLoss: 100 }),
      makeTrade({ result: 'loss', rMultiple: -1, profitLoss: -50 }),
      makeTrade({ result: 'loss', rMultiple: -1, profitLoss: -50 }),
    ];
    const result = computeAnalytics(trades, [], []);
    expect(result.summary.total).toBe(7);
    expect(result.summary.wins).toBe(5);
    expect(result.summary.losses).toBe(2);
    expect(result.summary.totalPnl).toBeCloseTo(375, 1);
  });

  it('باید با آرایه خالی کار کند', () => {
    const result = computeAnalytics([], [], []);
    expect(result.summary.total).toBe(0);
    expect(result.summary.winRate).toBe(0);
  });

  it('باید معاملات باز را در total حساب کند ولی در winRate نه', () => {
    const trades = [
      makeTrade({ result: 'win', status: 'closed' }),
      makeTrade({ result: 'open', status: 'open' }),
    ];
    const result = computeAnalytics(trades, [], []);
    expect(result.summary.total).toBe(2);
    expect(result.summary.open).toBe(1);
    expect(result.summary.wins).toBe(1);
  });

  it('باید winRate را به درستی محاسبه کند', () => {
    const trades = [
      makeTrade({ result: 'win', status: 'closed' }),
      makeTrade({ result: 'win', status: 'closed' }),
      makeTrade({ result: 'loss', status: 'closed' }),
      makeTrade({ result: 'loss', status: 'closed' }),
    ];
    const result = computeAnalytics(trades, [], []);
    expect(result.summary.winRate).toBe(50);
  });
});

describe('computeAnalytics — StrategyPerf', () => {
  it('باید عملکرد بر اساس استراتژی را صحیح جداسازی کند', () => {
    const trades = [
      makeTrade({ strategyId: 'strat-1', result: 'win', rMultiple: 2 }),
      makeTrade({ strategyId: 'strat-1', result: 'win', rMultiple: 1 }),
      makeTrade({ strategyId: 'strat-1', result: 'loss', rMultiple: -1 }),
      makeTrade({ strategyId: 'strat-2', result: 'loss', rMultiple: -1 }),
    ];
    const strategies = [
      { id: 'strat-1', name: 'FVG Strategy', description: '', icon: null, colorTag: null, isActive: true, createdAt: 0, updatedAt: 0 },
      { id: 'strat-2', name: 'OB Strategy', description: '', icon: null, colorTag: null, isActive: true, createdAt: 0, updatedAt: 0 },
    ];
    const result = computeAnalytics(trades, strategies, []);
    const strat1 = result.strategyPerf.find(p => p.strategyId === 'strat-1');
    expect(strat1?.total).toBe(3);
    expect(strat1?.wins).toBe(2);
  });
});

describe('computeAnalytics — BehaviorInsight', () => {
  it('باید consecutive losses را محاسبه کند', () => {
    const now = Date.now();
    const trades = [
      makeTrade({ result: 'win', status: 'closed', openedAt: now - 5000 }),
      makeTrade({ result: 'loss', status: 'closed', openedAt: now - 4000 }),
      makeTrade({ result: 'loss', status: 'closed', openedAt: now - 3000 }),
      makeTrade({ result: 'loss', status: 'closed', openedAt: now - 2000 }),
      makeTrade({ result: 'win', status: 'closed', openedAt: now - 1000 }),
    ];
    const result = computeAnalytics(trades, [], []);
    expect(result.behaviorInsight.consecutiveLosses).toBe(3);
  });

  it('باید consecutive wins را محاسبه کند', () => {
    const now = Date.now();
    const trades = [
      makeTrade({ result: 'win', status: 'closed', openedAt: now - 4000 }),
      makeTrade({ result: 'win', status: 'closed', openedAt: now - 3000 }),
      makeTrade({ result: 'win', status: 'closed', openedAt: now - 2000 }),
      makeTrade({ result: 'loss', status: 'closed', openedAt: now - 1000 }),
    ];
    const result = computeAnalytics(trades, [], []);
    expect(result.behaviorInsight.consecutiveWins).toBe(3);
  });
});
